from collections.abc import Callable
from typing import Any

import pendulum
import pyarrow as pa
from pendulum import Date

ConverterFunc = Callable[..., Any]


def convert_column(
    data: pa.Table,
    column_name: str,
    converter: ConverterFunc,
    converter_args: tuple = (),
    new_type: pa.DataType | None = None,
) -> pa.Table:
    """Converts a column in the table using the specified converter and optional new type.

    Args:
        data (pa.Table): The input table.
        column_name (str): The name of the column to convert.
        converter (Callable[[pa.Table], pa.Table]): The converter function to apply to each column value.
        new_type (pa.DataType | None, optional): The new data type for the column. Defaults to None.

    Returns:
        pa.Table: The table with the converted column.
    """

    if not isinstance(data, pa.Table):
        raise TypeError(f"df must be a pyarrow.Table, got {type(data).__name__}")

    if new_type and not isinstance(new_type, pa.DataType):
        raise TypeError(f"new_type must be a pyarrow.DataType, got {type(new_type).__name__}")

    if column_name not in data.column_names:
        raise ValueError(f"Column '{column_name}' not found in the table")

    column_index = data.column_names.index(column_name)

    # based on the new_type override the type or use the existing one
    old_type = data.schema[column_index].type

    field = pa.field(column_name, new_type or old_type)

    converted_data = pa.array(
        [converter(col, *converter_args) for col in data[column_name].to_pylist()], type=field.type
    )

    return data.set_column(column_index, field, converted_data)


def convert_date_func(value: str | None, fmt: str) -> Date | None:
    """Converts a date string (value) to a Date object using the specified format (fmt)."""

    if value is None:
        return None

    return pendulum.from_format(value, fmt=fmt)


Converters: dict[str, ConverterFunc] = {
    "date": convert_date_func,
}
