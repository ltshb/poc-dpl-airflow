# ruff: noqa: PT011
import pyarrow as pa
import pytest
from pendulum import Date, DateTime

from pipeline_tooling.converter import Converters, convert_column


def test_convert_column_basic():
    data = pa.table({"a": [1, 2, 3], "b": [10, 20, 30]})

    def conv(x) -> int:
        return x * 2

    result = convert_column(data, "a", conv)

    # The transformed column
    assert result.column("a").to_pylist() == [2, 4, 6]

    # Other columns remain unchanged
    assert result.column("b").to_pylist() == [10, 20, 30]


def test_convert_column_wrong_type_data():
    with pytest.raises(TypeError) as excinfo:
        convert_column("not a table", "a", lambda x: x)

    assert "pyarrow.Table" in str(excinfo.value)


def test_convert_column_wrong_type_column_type():
    data = pa.table({"a": [1, 2, 3]})

    with pytest.raises(pa.ArrowInvalid):
        convert_column(data, "a", str)


def test_convert_column_missing_column():
    data = pa.table({"a": [1, 2, 3]})

    with pytest.raises(ValueError):
        convert_column(data, "z", lambda x: x)


def test_convert_column_date_conversion():
    data = pa.table({"date": ["202607232100", "202202082200", "198310020830"]})

    result = convert_column(
        data,
        "date",
        Converters["date"],
        converter_args=("YYYYMMDDHHmm",),
        new_type=pa.timestamp("s"),
    )

    assert result.column("date").to_pylist() == [
        DateTime(2026, 7, 23, 21, 0),
        DateTime(2022, 2, 8, 22, 0),
        DateTime(1983, 10, 2, 8, 30),
    ]


def test_convert_column_date_conversion_with_date_only_result():
    # since we're providing date64 as the new type, the result should be date only
    # even though the parsing format includes time components
    data = pa.table({"date": ["202607232100", "202202082200", "198310020300"]})

    result = convert_column(
        data, "date", Converters["date"], converter_args=("YYYYMMDDHHmm",), new_type=pa.date64()
    )

    assert result.column("date").to_pylist() == [
        Date(2026, 7, 23),
        Date(2022, 2, 8),
        Date(1983, 10, 2),
    ]


def test_convert_date_func():
    result = Converters["date"]("202607232100", "YYYYMMDDHHmm")
    assert isinstance(result, DateTime)
