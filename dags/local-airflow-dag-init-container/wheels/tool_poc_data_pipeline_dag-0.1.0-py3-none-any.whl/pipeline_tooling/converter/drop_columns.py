import logging

import pyarrow as pa

logger = logging.getLogger("pipeline_tooling")


def drop_columns(table: pa.Table, columns: list[str]):
    logger.info(f"Going to drop columns: {columns}")
    return table.drop_columns(columns)
