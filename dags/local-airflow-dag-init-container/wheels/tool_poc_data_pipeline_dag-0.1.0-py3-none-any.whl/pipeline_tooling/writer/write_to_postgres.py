import logging

import boto3
import psycopg2
import pyarrow as pa
from psycopg2 import sql
from psycopg2.extras import execute_values

logger = logging.getLogger(__name__)


def write_to_postgres(
    data: pa.Table,
    db_endpoint: str,
    db_port: int,
    db_username: str,
    database_name: str,
    table_name: str,
) -> pa.Table:
    logger.info("Fetching postgres login token")
    client = boto3.client("rds", region_name="eu-central-1")
    token = client.generate_db_auth_token(
        DBHostname=db_endpoint, Port=db_port, DBUsername=db_username
    )

    logger.info("Connecting to postgres")
    conn = psycopg2.connect(
        host=db_endpoint,
        port=db_port,
        dbname=database_name,
        user=db_username,
        password=token,
        sslmode="require",
    )

    cols = [sql.Identifier(name) for name in data.schema.names]
    logger.info(f"Going to write columns: {cols}")

    with conn.cursor() as cursor:
        logger.info("Truncating table")
        stmt = sql.SQL("TRUNCATE TABLE {}").format(sql.Identifier(*table_name.split(".")))
        cursor.execute(stmt)

        logger.info("Writing data to postgres")
        for batch_counter, batch in enumerate(data.to_batches(max_chunksize=25)):
            logger.info(f"Inserting batch {batch_counter}")

            cols_sql = sql.SQL(", ").join(cols)
            stmt = sql.SQL("INSERT INTO {} ({}) VALUES %s").format(
                sql.Identifier(*table_name.split(".")),
                cols_sql,
            )

            data = [tuple(row.values()) for row in batch.to_pylist()]

            logger.info(f"Executing statement: {stmt.as_string(cursor)} with data {data}")

            execute_values(
                cursor,
                stmt,
                data,
            )

    logger.info("Committing changes")
    conn.commit()
    conn.close()

    return data
