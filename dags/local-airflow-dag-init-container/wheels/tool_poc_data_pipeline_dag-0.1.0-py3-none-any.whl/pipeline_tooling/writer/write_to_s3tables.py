import logging
import time
from typing import Any, TypedDict

import pyarrow as pa
from pyiceberg.catalog import Catalog
from pyiceberg.table import Table as pyTable
from pyiceberg.typedef import Identifier

from pipeline_tooling._shared.catalog import iceberg_catalog

logger = logging.getLogger("pipeline_tooling")

"""
Configuration class for S3 table settings.
"""


class S3TableWriteConfigBase(TypedDict):
    region: str
    table_bucket_arn: str
    namespace: str
    table_name: str


class S3TableWriteConfig(S3TableWriteConfigBase, total=False):
    # make schema optional
    schema: dict[str, Any] | None


def write_to_s3tables(  # noqa: PLR0913, PLR0917
    data: pa.Table,
    config: S3TableWriteConfig,
    create_if_not_exists: bool,
    load_if_exists: bool,
    replace_if_exists: bool = False,
    override_schema: bool = False,
) -> Identifier:
    """
    Writes data to an S3 table using PyIceberg.

    The schema can be omitted, in which case it will be inferred from the data.
    The idea is that the first write to the table will determine the schema.
    Every subsequent action has to conform to the schema already defined in the table.

    The argument replace_if_exists should be used sparsely, as it will replace the table's schema.
    Usually you shouldn't be required to use it, probably only for debugging purposes.

    Args:
        data: PyArrow Table to write
        config: S3TableConfig object containing the S3 configuration for s3 tables
        create_if_not_exists: Whether to create the table if it doesn't exist
        load_if_exists: Whether to load the table if it exists
        replace_if_exists: Whether to replace the table if it exists.
        override_schema: Whether to override the schema with the data's schema

    Returns:
        The name of the S3 table
    """
    if override_schema:
        raise ValueError(
            "override_schema is not supported yet"
        )  # not sure if we want to support this yet

    logger.info(config)

    if "schema" not in config or config["schema"] is None:
        # inferring the schema here if not provided
        table_schema = data.schema
    else:
        logger.info("Schema provided, using it")
        table_schema = config["schema"]

    with iceberg_catalog(config["region"], config["table_bucket_arn"]) as catalog:
        if replace_if_exists:
            drop_if_table_exists(catalog, config)

        table = get_or_create_table(
            catalog,
            config=config,
            table_schema=table_schema,
            create_if_not_exists=create_if_not_exists,
            load_if_exists=load_if_exists,
        )

        logger.info(f"Casting data schema to {table_schema}")
        # we need to cast the data into the given schema. The reason for that is that pyarrow's internal
        # schema might have nullable columns (if it's inferred from the data source) whereas the table schema
        # might require these columns to be non-nullable. Casting ensures the data matches the table schema.
        data = data.cast(table_schema)

        logger.info(f"Writing table {table.name()} to S3 tables catalog")

        table.overwrite(df=data)
        time.sleep(2)

    return data


def drop_if_table_exists(catalog: Catalog, config: S3TableWriteConfig) -> None:
    """Drops the table from the S3 catalog if it exists."""
    identifier = f"{config['namespace']}.{config['table_name']}"

    if catalog.table_exists(identifier):
        catalog.purge_table(identifier)
        # catalog.drop_table(identifier)
        logger.info(f"Table {identifier} dropped from S3 tables catalog")


def get_or_create_table(
    catalog: Catalog,
    config: S3TableWriteConfig,
    table_schema: dict[str, Any],
    create_if_not_exists: bool = False,
    load_if_exists: bool = False,
) -> pyTable:
    """
    Gets or creates a table in the S3 catalog.

    Depending on the flags, the table is either loaded if it exists or created if it doesn't.

    Args:
        config: The S3 table configuration
        table_schema: The schema of the table
        create_if_not_exists: Whether to create the table if it doesn't exist
        load_if_exists: Whether to load the table if it exists

    Returns:
        The PyIceberg table instance
    """

    table_identifier = f"{config['namespace']}.{config['table_name']}"

    if catalog.table_exists(table_identifier):
        if load_if_exists:
            logger.info(f"Loading existing table {table_identifier}")
            table_handle = catalog.load_table(table_identifier)
        else:
            raise ValueError(f"Table {table_identifier} already exists and load_if_exists is False")
    elif create_if_not_exists:
        logger.info(f"Creating new table {table_identifier}")
        catalog.create_namespace_if_not_exists(config["namespace"])
        table_handle = catalog.create_table(table_identifier, schema=table_schema)
    else:
        raise ValueError(
            f"Table {table_identifier} does not exist and create_if_not_exists is False"
        )

    return table_handle
