import logging
from collections.abc import Generator
from contextlib import contextmanager

from pyiceberg.catalog import Catalog
from pyiceberg.catalog import load_catalog as pyiceberg_load_catalog

logger = logging.getLogger("pipeline_tooling")


@contextmanager
def iceberg_catalog(region: str, table_bucket_arn: str) -> Generator[Catalog]:
    """Load an iceberg catalog

    Connect to apache iceberg (s3 tables) and return a handle.
    """

    logger.info(f"Loading catalog for region {region} for bucket {table_bucket_arn}")

    catalog = pyiceberg_load_catalog(
        "s3tables",
        **{
            "type": "rest",
            "warehouse": table_bucket_arn,
            "uri": f"https://s3tables.{region}.amazonaws.com/iceberg",
            "rest.sigv4-enabled": "true",
            "rest.signing-name": "s3tables",
            "rest.signing-region": region,
        },
    )

    try:
        yield catalog

    finally:
        logger.info("Closing iceberg catalog")
        catalog.close()
