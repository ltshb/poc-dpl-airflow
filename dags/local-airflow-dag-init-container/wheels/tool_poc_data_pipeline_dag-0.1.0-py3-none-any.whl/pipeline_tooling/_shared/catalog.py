import logging

from pyiceberg.catalog import Catalog
from pyiceberg.catalog import load_catalog as pyiceberg_load_catalog

logger = logging.getLogger("pipeline_tooling")


def load_catalog(region: str, table_bucket_arn: str) -> Catalog:
    logger.info(f"Loading catalog for region {region} for bucket {table_bucket_arn}")
    return pyiceberg_load_catalog(
        "s3tables",
        **{
            "type": "rest",
            "warehouse": table_bucket_arn,
            "uri": f"https://s3tables.{region}.amazonaws.com/iceberg",
            "rest.sigv4-enabled": "true",
            "rest.signing-name": "s3tables",
            "rest.signing-region": region,
        },
    )
