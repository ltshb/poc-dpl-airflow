from collections.abc import Callable
from typing import Any

import pyarrow as pa

ValidatorFunc = Callable[..., Any]


def validate_column(
    data: pa.Table,
    column: str,
    callback_func: Callable,
    validator_args: tuple = (),
    validation_error: str = "Failed",
) -> None:
    """Validate a single column of a py Arrow Dataframe with a callback function

    Args:
        data: The py Arrow Table to validate
        column: The name of the column to validate
        callback_func: A function to be applied to every value of the column
        validator_args: Additional arguments to pass to the validator function
        validation_error: The error message to use if validation fails to give more context

    Raises:
        ValueError: If the column is not found in the dataframe

    returns:
        The validated pyArrow Table
    """

    # Basic input validations
    if not isinstance(data, pa.Table):
        raise TypeError(f"df must be a pyarrow.Table, got {type(data).__name__}")

    if column not in data.column_names:
        raise ValueError(
            f"Column '{column}' not found in dataframe columns {list(data.column_names)}"
        )

    # Retrieve the column and normalize to a single Array
    col = data.column(column)

    for val in col:
        result = callback_func(val.as_py(), *validator_args)

        if result is False:
            raise ValueError(
                f"Validation failed for column '{column}' at row (value={val}): {validation_error}"
            )

    # If the callback raises an exception, bubble up; otherwise, validation passes
    return data


def validate_range_func(value: int, min: int, max: int, ignore_empty: bool = False) -> bool:
    if ignore_empty and value is None:
        return True
    return min <= value <= max


def validate_precision_func(value: float, precision: int, ignore_empty: bool = False) -> bool:
    if ignore_empty and value is None:
        return True
    return round(value, precision) == value


Validators: dict[str, ValidatorFunc] = {
    "range": validate_range_func,
    "precision": validate_precision_func,
}
