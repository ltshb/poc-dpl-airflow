import pytest

from pipeline_tooling.validator import Validators


def test_validate_range_basic():
    range_func = Validators["range"]

    # inside range
    assert range_func(5, 0, 10) is True

    # edges are inclusive
    assert range_func(0, 0, 10) is True
    assert range_func(10, 0, 10) is True

    # outside range
    assert range_func(-1, 0, 10) is False
    assert range_func(11, 0, 10) is False


def test_validate_range_ignore_empty():
    range_func = Validators["range"]

    # None is accepted when ignore_empty=True
    assert range_func(None, 0, 10, ignore_empty=True) is True

    # When ignore_empty is False, comparing None raises a TypeError
    with pytest.raises(TypeError):
        range_func(None, 0, 10, ignore_empty=False)


def test_validate_precision_basic():
    precision_func = Validators["precision"]
    # exact precision match
    assert precision_func(1.23, 2) is True
    assert precision_func(1.2, 1) is True
    # does not match precision
    assert precision_func(1.234, 2) is False
    assert precision_func(1.29, 1) is False


def test_validate_precision_zero_precision():
    precision_func = Validators["precision"]

    # precision 0 checks integer-ness
    assert precision_func(2.0, 0) is True
    assert precision_func(2.5, 0) is False


def test_validate_precision_ignore_empty():
    precision_func = Validators["precision"]

    # None accepted when ignore_empty=True
    assert precision_func(None, 2, ignore_empty=True) is True

    # When ignore_empty is False, round(None, ...) raises a TypeError
    with pytest.raises(TypeError):
        precision_func(None, 2, ignore_empty=False)
