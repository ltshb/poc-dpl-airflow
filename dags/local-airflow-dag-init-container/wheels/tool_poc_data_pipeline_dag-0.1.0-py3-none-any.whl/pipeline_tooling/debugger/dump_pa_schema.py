import logging

import pyarrow as pa

logger = logging.getLogger("pipeline_tooling")


def dump_pa_table_schema(table: pa.Table) -> None:
    logger.info(f"Table Schema: {table.schema}")
    return table
