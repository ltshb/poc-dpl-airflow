import logging

import pyarrow as pa

logger = logging.getLogger("pipeline_tooling")


def dump_pa_table(table: pa.Table) -> None:
    logger.info(f"Table: {table}")
    return table
