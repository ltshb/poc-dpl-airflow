import pyarrow as pa


def dump_pa_table(table: pa.Table) -> None:
    print(table)
