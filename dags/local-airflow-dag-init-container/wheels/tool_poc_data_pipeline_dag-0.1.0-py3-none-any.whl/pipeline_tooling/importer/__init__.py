"""
Library for all importer nodes

This module provides functions to import resources from various sources.

Base Definition:
- Input: string representing the id, path, or name of the resource to import
- Output: a file object (as defined in Python's glossary)
"""

from .download_from_s3 import download_from_s3

__all__ = [
    "download_from_s3",
]
