# defer annotation evaluation for the recursive type hint
from __future__ import annotations

from collections.abc import Callable
from typing import Literal, TypedDict


class SimpleNode(TypedDict):
    type: Literal["SimpleNode"]
    func: Callable
    args: dict


class ForkNode(TypedDict):
    type: Literal["ForkNode"]
    left: list[SimpleNode | ForkNode]
    right: list[SimpleNode | ForkNode]
    final: list[SimpleNode | ForkNode]


Node = SimpleNode | ForkNode
