import logging

from pipeline_tooling import reader

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_reader(node_name: str, node_args: dict) -> Node:
    logger.info(f"Going to generate reader for node: {node_name}")

    return SimpleNode(func=getattr(reader, node_name), args=node_args, type="SimpleNode")
