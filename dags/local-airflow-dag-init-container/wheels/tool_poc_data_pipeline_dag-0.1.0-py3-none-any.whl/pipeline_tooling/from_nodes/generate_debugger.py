import logging

from pipeline_tooling import debugger

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_debugger(node_name: str, node_args: dict) -> Node:
    """Generate an debugger node function."""

    logger.info(f"Going to generate debugger for node: {node_name}")

    return SimpleNode(type="SimpleNode", func=getattr(debugger, node_name), args=node_args)
