import logging

import pyarrow as pa

from pipeline_tooling import writer

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_writer(node_name: str, node_args: dict) -> Node:
    logger.info(f"Going to generate writer for node: {node_name}")

    logger.info(f"Node: {node_name}, node_args: {node_args}")

    if (
        node_name == "write_to_s3tables"
        and "config" in node_args
        and "schema" in node_args["config"]
    ):
        # convert the schema from the YAML format to a PyArrow schema
        logger.info("Converting schema from YAML to PyArrow")
        schema = generate_pa_schema(node_args["config"]["schema"])
        node_args["config"]["schema"] = schema
    else:
        logger.info("No schema conversion needed")

    return SimpleNode(type="SimpleNode", func=getattr(writer, node_name), args=node_args)


def generate_pa_schema(schema: list) -> list:
    """
    Convert a list of schema definitions to a PyArrow schema.

    Args:
        schema: List of dictionary objects with 'name', 'type', and 'nullable' keys

    Returns:
        A list of PyArrow field definitions
    """
    fields = []

    for item in schema:
        name = item["name"]
        type_str = item["type"]
        nullable = item.get("nullable", True)

        # Create PyArrow field using the same type names as in YAML
        field = pa.field(name, type_str, nullable=nullable)
        fields.append(field)

    return pa.schema(fields)
