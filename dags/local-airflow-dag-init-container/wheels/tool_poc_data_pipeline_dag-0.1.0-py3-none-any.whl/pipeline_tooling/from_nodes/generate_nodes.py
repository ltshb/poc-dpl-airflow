import logging
import re

from .generate_converter import generate_converter
from .generate_importer import generate_importer
from .generate_reader import generate_reader
from .generate_writer import generate_writer
from .Node import ForkNode, Node

logger = logging.getLogger("pipeline_tooling")


def generate_node_tree(data: dict, stage: str, params: dict | None = None) -> list[Node]:
    try:
        name = next(key for key in data if key.startswith("pipeline_"))
    except StopIteration as e:
        raise ValueError("No pipeline entry found in data") from e

    nodes = data[name]

    if stage not in nodes:
        raise ValueError(f"Stage {stage} not found in nodes: {nodes}")

    selected_stage = nodes[stage]
    logger.info(f"Generating nodes for stage: {stage}")
    return generate_nodes(selected_stage, params)


def generate_fork(node_args: dict, params: dict) -> ForkNode:
    logger.info(f"Going to generate fork node with args: {node_args}")
    left = node_args["left"]
    right = node_args["right"]
    final = node_args["final"]

    return ForkNode(
        type="ForkNode",
        left=generate_nodes(left, params),
        right=generate_nodes(right, params),
        final=generate_nodes(final, params),
    )


def generate_nodes(nodes: dict, params: dict | None = None) -> list[Node]:
    node_funcs = []

    logger.info(f"Generating nodes: {nodes}")

    for node in nodes:
        node_key = next(iter(node.items()))[0]
        logger.info(f"Node key: {node_key}")

        node_type = node_key.split(".")[0]
        node_name = node_key.split(".")[1]

        logger.info(f"Node type: {node_type}, node name: {node_name}")

        node_args = node[node_key]

        if params is not None and node_args is not None:
            node_args = interpolate_params(node_args, params)

        logger.info(f"Node args: {node_args}")

        if node_type == "node":
            if node_name == "fork":
                node_funcs.append(generate_fork(node_args, params))
            else:
                raise NotImplementedError(f"Node type: {node_type}, node name: {node_name}")

        if node_type == "converter":
            node_funcs.append(generate_converter(node_name, node_args))

        if node_type == "reader":
            node_funcs.append(generate_reader(node_name, node_args))

        if node_type == "writer":
            node_funcs.append(generate_writer(node_name, node_args))

        if node_type == "importer":
            node_funcs.append(generate_importer(node_name, node_args))

    return node_funcs


def interpolate_params(node_args: dict, params: dict) -> dict:
    """Interpolate parameters in node arguments using the provided params dictionary.

    Example:
        node_args = {"path": "{{path}}"}
        params = {"path": "/data"}
        result = interpolate_params(node_args, params)
        print(result)  # Output: {"path": "/data"}

    Args:
        node_args (dict): The node arguments to interpolate.
        params (dict): The parameters to use for interpolation.

    Returns:
        dict: The node arguments with interpolated values.
    """
    logger.info(f"Params are: {params}")

    for key, value in node_args.items():
        if isinstance(value, str):
            match = re.match(r"^{{(.+)}}$", value)
            if match:
                param_name = match.group(1).strip()
                if param_name in params:
                    node_args[key] = params[param_name]

    return node_args
