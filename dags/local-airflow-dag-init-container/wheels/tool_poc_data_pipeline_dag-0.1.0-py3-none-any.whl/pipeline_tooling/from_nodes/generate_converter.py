import logging

import pyarrow as pa
import pyarrow.compute as pc

from pipeline_tooling import converter

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_converter(node_name: str, node_args: dict) -> Node:
    """Map the input to a converter function

    Basically map the input to a converter function, the ones that are exported
    by the `converter` module. In case of `convert_column_compute`, the converter callback
    is looked up in `pyarrow.compute`.

    Args:
        node_name (str): The name of the node to generate a converter for
        node_args (dict): The arguments for the node
    """

    logger.info(f"Going to generate converter for node: {node_name}")

    if node_name == "convert_column_compute":
        conf_func = node_args["converter"]

        # get the actual converter function from pyarrow.compute
        pc_converter_func = getattr(pc, conf_func)
        node_args["converter"] = pc_converter_func

        if "target_type" in node_args:
            conf_type = node_args["target_type"]
            pa_target_type = getattr(pa, conf_type)
            node_args["target_type"] = pa_target_type

    if node_name == "add_column":
        # interpret the value_callback string as a callable function
        callback = node_args.pop("value_callback")
        namespace = {}
        exec(callback, namespace)  # noqa: S102
        node_args["value_callback"] = namespace["callback"]

    converter_func = getattr(converter, node_name)
    return SimpleNode(func=converter_func, args=node_args, type="SimpleNode")
