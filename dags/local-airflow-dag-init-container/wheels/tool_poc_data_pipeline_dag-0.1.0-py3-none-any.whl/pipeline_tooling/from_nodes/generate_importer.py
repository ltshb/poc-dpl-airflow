import logging

from pipeline_tooling import importer

from .Node import Node, SimpleNode

logger = logging.getLogger("pipeline_tooling")


def generate_importer(node_name: str, node_args: dict) -> Node:
    """Generate an importer node function."""

    logger.info(f"Going to generate importer for node: {node_name}")

    return SimpleNode(type="SimpleNode", func=getattr(importer, node_name), args=node_args)
