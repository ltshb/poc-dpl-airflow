"""
Library for all reader nodes

This module provides functionality for reading data from file objects and converting them into PyArrow tables.

Base Definition:
- Input: A file object (file-like object)
- Output: A PyArrow Table
"""

from .parse_csv import parse_csv
from .parse_yaml import parse_yaml
from .read_from_s3tables import read_from_s3tables

__all__ = ["parse_csv", "parse_yaml", "read_from_s3tables"]
