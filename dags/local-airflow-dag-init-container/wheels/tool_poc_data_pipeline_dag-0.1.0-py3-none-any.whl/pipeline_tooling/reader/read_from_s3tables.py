import logging

import pyarrow as pa

from pipeline_tooling._shared.catalog import iceberg_catalog

logger = logging.getLogger("pipeline_tooling")


def read_from_s3tables(
    region: str, table_bucket_arn: str, namespace: str, table_name: str
) -> pa.Table:
    """Read a table from an S3 tables catalog.

    Args:
        region: The AWS region.
        table_bucket_arn: The ARN of the S3 bucket containing the table.
        namespace: The namespace of the table.
        table_name: The name of the table.

    Returns:
        The table as a PyArrow table.
    """
    table_identifier = f"{namespace}.{table_name}"

    logger.info(f"Reading table {table_identifier} from S3 tables catalog")

    with iceberg_catalog(region, table_bucket_arn) as catalog:
        if not catalog.table_exists(table_identifier):
            raise FileNotFoundError(f"S3 table {table_identifier} not found")

        table = catalog.load_table(table_identifier)

        return table.scan().to_arrow()
