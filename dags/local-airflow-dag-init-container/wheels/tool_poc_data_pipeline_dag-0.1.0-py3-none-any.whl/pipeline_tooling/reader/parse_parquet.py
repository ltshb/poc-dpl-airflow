import io
import logging
import typing

import pyarrow as pa
import pyarrow.parquet as pq

logger = logging.getLogger("pipeline_tooling")


def parse_parquet(stream: typing.IO[bytes]) -> pa.Table:
    logger.info("Read parquet file from byte stream")

    # materialize into a seekable buffer
    buffer = io.BytesIO(stream.read())
    table = pq.read_table(buffer)
    stream.close()
    return table
