import logging
import typing

import pyarrow as pa
from pyarrow import csv

logger = logging.getLogger("pipeline_tooling")


def parse_csv(file: typing.IO[str], encoding: str, delimiter: str) -> pa.Table:
    """
    Parse a CSV file into a PyArrow Table.

    Args:
        file (io.TextIOWrapper): The CSV file to parse.

    Returns:
        pa.Table: The parsed CSV data as a PyArrow Table.
    """
    logger.info(f"Parsing CSV file with encoding {encoding} and delimiter {delimiter}")

    # https://arrow.apache.org/docs/python/generated/pyarrow.csv.ReadOptions.html#pyarrow.csv.ReadOptions
    # https://arrow.apache.org/docs/python/generated/pyarrow.csv.ParseOptions.html#pyarrow.csv.ParseOptions
    # https://arrow.apache.org/docs/python/generated/pyarrow.csv.ConvertOptions.html#pyarrow.csv.ConvertOptions

    return csv.read_csv(
        file,
        read_options=csv.ReadOptions(encoding=encoding),
        parse_options=csv.ParseOptions(delimiter=delimiter),
    )
