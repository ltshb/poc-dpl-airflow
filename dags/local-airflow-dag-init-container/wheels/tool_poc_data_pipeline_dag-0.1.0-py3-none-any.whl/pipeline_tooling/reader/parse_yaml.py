import logging
import typing

import yaml

logger = logging.getLogger("pipeline_tooling")


def parse_yaml(stream: typing.IO[str]) -> dict:
    logger.info("Going to parse yaml")
    return yaml.safe_load(stream)
